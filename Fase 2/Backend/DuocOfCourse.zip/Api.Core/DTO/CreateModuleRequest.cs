﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Api.Core.DTO
{
    public class CreateModuleRequest
    {
        public string Title { get; set; } = string.Empty;
    }
}
