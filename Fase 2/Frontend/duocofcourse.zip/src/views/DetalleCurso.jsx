import DetCurso from "../components/DetCurso";
export default function DetalleCurso() {
  return (
    <section className="p-8">
      <main>
          <DetCurso />
        </main>
    </section>
  );
}