import ExpCursos from "../components/ExpCursos";
export default function ExplorarCursos() {
  return (
    <section className="p-8">
      <main>
        <ExpCursos />
      </main>
    </section>
  );
}