import CalificacionesComp from "../components/CalificacionesComp";
export default function Calificaciones() {
  return (
    <section className="p-8">
      <CalificacionesComp />
    </section>
  );
}