import CertificadoCard from "../components/CertificadoCard";

export default function Certificados() {
  return (
    <section className="p-8">
      <CertificadoCard />
    </section>
  );
}