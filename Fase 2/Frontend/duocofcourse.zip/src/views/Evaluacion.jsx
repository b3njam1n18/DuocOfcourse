import EvaluacionComp from "../components/EvaluacionComp";
export default function Evaluaciones() {
  return (
    <section className="p-8">
      <main>
          <EvaluacionComp />
        </main>
    </section>
  );
}