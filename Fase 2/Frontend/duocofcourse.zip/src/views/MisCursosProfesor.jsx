import Cursos from "../components/CursosProfesor";
export default function MisCursosProfesor() {
  return (
    <section className="p-8">
      <main>
          <Cursos />
      </main>
    </section>
  );
}