import Class from "../components/Class";
export default function Clase() {
  return (
    <section className="p-8">
      <main>
          <Class />
        </main>
    </section>
  );
}