import Cursos from "../components/Cursos";
export default function MisCursos() {
  return (
    <section className="p-8">
      <main>
          <Cursos />
      </main>
    </section>
  );
}