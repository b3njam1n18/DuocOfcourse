import EvaluacionesComp from "../components/EvaluacionesComp";
export default function Evaluaciones() {
  return (
    <section className="p-8">
      <main>
          <EvaluacionesComp />
        </main>
    </section>
  );
}